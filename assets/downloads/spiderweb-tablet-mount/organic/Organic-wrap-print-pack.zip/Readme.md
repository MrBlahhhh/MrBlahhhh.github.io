# Organic double-socket arm for 1-inch balls

The two jaws enclose each ball with curved, open ribs. The 62 mm version is the first physical test piece. The spherical faces use a 12.75 mm radius for a nominal 25.4 mm ball. A flat outer boss supports the washer. The two planar inner references leave a nominal 2 mm gap for clamping. 

## Print and assemble

1. Print two copies of the same jaw and one existing M6 hand knob. Put the flat outer washer land on the bed with the ball seats facing up. Put the knob's small washer face on the bed. Use dried PAHT-CF, a hardened 0.4 mm nozzle, your calibrated filament profile, 0.20 mm layers, five walls and 40% gyroid. Inspect the transverse windows for bridge quality. Keep support material out of the seats and the guide socket.
2. Use one **M6 × 1.0 × 45 mm, 90° countersunk hex-socket screw** with length measured including its head, one M6 plain 10 mm across-flats nut and one 6.4 × 18 × 1.6 mm wide washer. The original printed knob fits the nut. The conical seat has a 13.6 mm mouth and a 6.8 mm through bore. The previous external hex-head screw requires the original jaw. [Countersunk screw dimensions](https://eshop.boellhoff.de/out/media/pdf/ISO_10642_Stahl_10.9___en.pdf)
3. Flip one jaw 180° around its length so each post enters the opposing guide. Seat both balls, insert the screw, then fit the washer and knob. Hold the screw with a hex key if it turns. Check the screw seats and the knob engages the nut fully while the jaws still have a visible gap. Inspect the countersink and rib roots as you tighten.
4. Test with a tethered dummy tablet. Mark both balls at the jaws, load in both directions and look for slipping, permanent set, cracking and loss of grip after a warm soak. A payload rating, tightening torque and hot-cabin life still require physical measurements.

## How the load results changed the geometry

The study used an FEA-guided shape and size search. Smoothed stresses from the earlier bending, sideways and clamp analyses set the thickness along the outer splines. The generator tested bowed and inflected window paths and placed openings in lower-stress regions. A second set of curved windows crosses the side walls. Their height follows a search through the neutral region of the rail. The spherical wrap openings were selected from 32 feasible angular positions around the 62 mm seat. The side branches and bolt bosses are mirrored. A guide post and its sliding socket orient the two identical jaws.

The first open layout concentrated load at the socket shoulders. Widening the roots improved bending. Adding transverse openings exposed a separate weakness in the single-rib load test. The final comparison tested a broad reinforcement and a localized increase around the high-stress arc. The model is an editable SolidCraft lofted solid with exact spherical contact faces and tapered junctions. The face positions and node loads come from a linear simulation of a printed jaw.

## Displacement screens

Values are new jaw / original solid-cup jaw under the same load. Each trial uses a 25% maximum increase in displacement relative to the solid jaw. The local 20 N rim screen extends the earlier 25% bending criterion to an individual contact sector. A screen pass selects a bench prototype. In particular, the 95 mm local result sits very close to the cutoff.

| Length (mm) | Vertical movement (mm) | Side movement (mm) | Local rim movement (mm) | Sliced g per jaw | Outcome |
|---:|---:|---:|---:|---:|---|
| 62 | 0.184 / 0.184 | 0.047 / 0.057 | 0.03863 / 0.03412 | 19.44 / 15.77 | Bench prototype |
| 95 | 0.440 / 0.474 | 0.118 / 0.141 | 0.09165 / 0.07336 | 31.11 / 24.51 | Bench prototype |
| 120 | 0.746 / 0.823 | 0.198 / 0.241 | 0.15057 / 0.13314 | 40.81 / 31.11 | Bench prototype |
| 150 | 1.221 / 1.422 | 0.311 / 0.410 | 0.24703 / 0.25134 | 54.10 / 39.04 | Bench prototype |

The 3 g case uses a 1 kg tablet and case, with its center of mass 50 mm beyond the outer ball. A total force of 29.42 N splits equally between the two jaws. The opposing ball contact region is fixed. The individual rim case applies 20 N distributed in outward radial directions over a 30° outboard sector above z = 11.2 mm on the loaded seat. Its displacement is the load-weighted mean radial movement. The screw-head and washer checks use a separate 100 N clamp load. The head calculation includes the outward component from the 90° countersink.

The model approximates dry PAHT-CF with in-plane modulus 3.86 GPa and through-layer modulus 2.18 GPa. It treats material inside the printed skins as 25% as stiff as the shell. Local stresses depend on the mesh and on the chosen contact boundary. Grip depends on the actual rubber, printed surface and clamp load. A breaking load requires a physical test or a validated fracture model. [PAHT-CF material data](https://store.bblcdn.eu/s8/default/91dea87af3414d878a0696d2c51b98f7/Bambu_PAHT-CF_Technical_Data_Sheet_V2.pdf)

| Length (mm) | Maximum width (mm) | Spherical contact per seat (mm²) | Original contact retained | Vertical motion, 2.4 → 1.5 mm mesh (mm) | Fine vertical stress, 99th percentile / peak (MPa) |
|---:|---:|---:|---:|---:|---:|
| 62 | 46.5 | 516.5 | 73.6% | 0.178 → 0.184 | 1.80 / 7.31 |
| 95 | 47.2 | 493.6 | 70.4% | 0.427 → 0.440 | 2.21 / 9.83 |
| 120 | 47.0 | 512.6 | 73.1% | 0.727 → 0.746 | 2.70 / 12.40 |
| 150 | 46.9 | 519.0 | 74.0% | 1.192 → 1.221 | 3.01 / 13.88 |

## 62 mm design history

| Design | Vertical (mm) | Side (mm) | One rim (mm) | Decision |
|---|---:|---:|---:|---|
| First open layout | 0.448 | 0.258 | — | Rejected for flex |
| Wider socket roots | 0.261 | 0.075 | — | Rejected for flex |
| Light rib trial | 0.235 | 0.065 | 0.0632 | Rejected for flex |
| Open rib trial | 0.210 | 0.055 | 0.0522 | Rejected at the rim |
| Balanced rib trial | 0.183 | 0.045 | 0.0402 | Screen passed |
| Thick rib trial | 0.168 | 0.039 | 0.0336 | Screen passed |
| Open cross windows | 0.229 | 0.069 | 0.0606 | Rejected at the rim |
| Balanced cross windows | 0.193 | 0.052 | 0.0446 | Rejected at the rim |
| Broad root reinforcement | 0.175 | 0.044 | 0.0364 | Screen passed |
| Local rim reinforcement | 0.184 | 0.047 | 0.0386 | Selected for bench testing |

## Files and length adjustment

Open the SolidCraft file for the closest supplied length and edit **ArmLength** for tip-to-tip length. The 62 mm native file was also rebuilt at 68 mm and checked as one closed solid. The supplied lengths each have their own computed paths. Re-run the analysis before relying on a new span. Print meshes passed single-body, watertight, winding, socket-section, guide, stem and washer-land checks and were sliced with the same comparison profile as the solid-cup reference.

The generator uses Python 3 and SolidCraft CLI 0.45.0. Keep `build.py`, `paths.json` and `rib-field.json` together. Run `python3 build.py 62 output` for the short prototype. `field.py` and `paths.py` record how the stored load fields drive the profiles. The `analysis` folder contains the tetrahedral meshing and load-case code. `results.json` contains numerical results and mesh counts.

The comparison film and individual H.264 clips visualize the solved nodal displacements and surface von Mises stresses. They ramp from zero to the modeled load. The amplification is printed on each frame. Exceeding the displacement limit means the design was too flexible for the selected criterion. The films show elastic deflection up to the modeled load.
