from pathlib import Path
import gmsh,numpy as np,json,sys
root=Path(__file__).parent
def inspect(f):
    gmsh.initialize();gmsh.option.setNumber('General.Terminal',0)
    gmsh.model.occ.importShapes(str(f));gmsh.model.occ.synchronize()
    info=[];head=0;land=0
    for _,t in gmsh.model.getEntities(2):
        typ=gmsh.model.getType(2,t);c=np.array(gmsh.model.occ.getCenterOfMass(2,t));a=gmsh.model.occ.getMass(2,t)
        if typ=='Sphere':info.append([*c,a])
        if typ=='Plane' and abs(c[2]-4.3)<1e-6:head+=a
        if typ=='Plane' and abs(c[2])<1e-6:land+=a
    v=gmsh.model.getEntities(3);assert len(v)==1
    gmsh.finalize()
    return np.array(sorted(info)),head,land
if __name__=='__main__':
    f=root/sys.argv[1]; l=int(f.name.split('-')[0])
    sb,hb,bed=inspect(root/f'{l}-base/Jaw.step')
    se,he,foot=inspect(f/'Jaw.step')
    np.testing.assert_allclose(sb,se,atol=1e-4,rtol=2e-6)
    assert abs(he-hb)<1e-4
    print(f.name,{'seat_area_mm2':se[:,3].round(3).tolist(),'hex_seat_area_mm2':round(he,4),'bed_land_mm2':round(foot,2),'original_bed_land_mm2':round(bed,2)})
