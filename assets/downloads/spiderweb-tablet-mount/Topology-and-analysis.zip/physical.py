from pathlib import Path
import json,sys
import numpy as np
import trimesh
G=Path(sys.argv[1])
out=Path(sys.argv[2])
sys.path.insert(0,str(G));from fit import hit
for label,f in json.loads(out.read_text()).items():
 l=int(label);p=Path(f)
 m=trimesh.load_mesh(p/'Jaw.stl')
 assert m.is_volume and m.is_watertight and m.is_winding_consistent
 voids=[]
 if m.body_count!=1:
    shells=m.split(only_watertight=False)
    assert all(x.is_watertight for x in shells) and sum(x.volume>0 for x in shells)==1
    voids=[abs(float(x.volume)) for x in shells if x.volume<0]
    assert max(voids,default=0)<.01,(l,voids)
 (p/'meshcheck.json').write_text(json.dumps(dict(single_material_body=True,closed_internal_void_volumes_mm3=voids,extents_mm=m.extents.tolist(),volume_mm3=m.volume)))
 native=json.loads((p/'native.json').read_text())
 assert native['body_count']==1 and native['bodies'][0]['closed']
 assert abs(m.volume/native['total']['volume_mm3']-1)<.002
 assert abs(m.extents[0]-l)<.02
 # The solid angles available for both balls, the seat radius, and the fasteners are all kept.
 # The underside of the sculpted cup may be recessed; its interior must terminate on the same sphere.
 tri=m.triangles
 def check(x,y,z):
    v=hit(tri,x,y);assert len(v)==len(z) and np.allclose(v,z,atol=.09),(l,x,y,v,z)
 for sign in [-1,1]:
    cx=sign*(l/2-8.001)
    for dx,y in [(0,0),(0,6.2),(-sign*4.2,7.1),(-sign*6.5,.9),(sign*5.,8.)]:
        hs=hit(tri,cx+dx,y);assert abs(hs[-1]-16.5+(12.75**2-dx**2-y*y)**.5)<.06
    check(sign*(l/2-.6),.02,[])
 check(.03,.04,[]);check(1,4.3,[4.3,15.5]);check(.04,-9.49,[0,9.8]);check(.04,9.49,[0,20.2])
 for a in np.linspace(0,2*np.pi,36,endpoint=False):
    for r in (6.3,8.95):assert hit(tri,r*np.cos(a),r*np.sin(a))[0]==0
 print(l,'watertight; extents',m.extents.round(3).tolist(),'; material volume',round(m.volume),'; all interface samples OK',flush=True)
