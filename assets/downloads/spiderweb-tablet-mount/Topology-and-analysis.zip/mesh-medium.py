import sys
from pathlib import Path
import gmsh, numpy as np
h=float(sys.argv[1])
gmsh.initialize();gmsh.option.setNumber('General.Terminal',0)
gmsh.model.occ.importShapes("Jaw.step");gmsh.model.occ.synchronize()
faces=gmsh.model.getEntities(2)
def center(tag): return np.array(gmsh.model.occ.getCenterOfMass(2,tag))
sphere=[t for _,t in faces if gmsh.model.getType(2,t)=='Sphere']
assert len(sphere)==2
left,right=sorted(sphere,key=lambda t:center(t)[0])
head=[t for _,t in faces if abs(center(t)[2]-4.3)<1e-5 and gmsh.model.getType(2,t)=='Plane']
back=[t for _,t in faces if abs(center(t)[2])<1e-6 and gmsh.model.getType(2,t)=='Plane']
assert len(head)==1 and back and len(gmsh.model.getEntities(3))==1
gmsh.option.setNumber('Mesh.MeshSizeMax',h)
gmsh.option.setNumber('Mesh.MeshSizeMin',h*.32)
gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',8 if h>2 else 11)
gmsh.option.setNumber('Mesh.Algorithm3D',1)
gmsh.option.setNumber('Mesh.Optimize',1)
gmsh.option.setNumber('General.NumThreads',1)
gmsh.model.mesh.generate(3)
tags,coords,_=gmsh.model.mesh.getNodes()
lut=np.full(int(np.max(tags))+1,-1);lut[tags.astype(int)]=np.arange(len(tags))
def elements(etype,entity=-1):
    return lut[gmsh.model.mesh.getElementsByType(etype,entity)[1].astype(int)].reshape(-1,{2:3,4:4}[etype])
def surface(tags):return np.vstack([elements(2,t) for t in tags])
data=dict(x=coords.reshape(-1,3),tet=elements(4),skin=elements(2),right=surface([right]),left=surface([left]),head=surface(head),back=surface(back))
gmsh.finalize()
print(h,len(data['x']),len(data['tet']),flush=True)
np.savez_compressed(f'mesh-{h:g}.npz',**data)
