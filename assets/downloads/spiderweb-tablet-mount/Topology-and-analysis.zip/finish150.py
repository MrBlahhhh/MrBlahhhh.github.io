from pathlib import Path
import sys,numpy as np,trimesh
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components,breadth_first_order
p=Path(sys.argv[1]);a=np.load(p/'surface-alternate.npz')
v,f=a['v'],a['f'];m=trimesh.Trimesh(v,f,process=True);print('input',len(m.faces),m.is_watertight,m.is_winding_consistent,m.volume,flush=True)
assert m.is_watertight
if not m.is_winding_consistent:
 f=m.faces.copy();edges=f[:,[0,1,1,2,2,0]].reshape(-1,2);i=np.argsort(m.edges_unique_inverse,kind='stable').reshape(-1,2)
 pairs=i//3;s=np.where((edges[i[:,0],0]==edges[i[:,1],1]),1,-1).astype(np.int8)
 A=coo_matrix((np.r_[s,s],(np.r_[pairs[:,0],pairs[:,1]],np.r_[pairs[:,1],pairs[:,0]])),shape=(len(f),len(f))).tocsr()
 cnt,label=connected_components(A,directed=False)
 for c in range(cnt):
    order,parent=breadth_first_order(A,int(np.flatnonzero(label==c)[0]),directed=False)
    child=order[1:];relation=np.asarray(A[parent[child],child]).reshape(-1)
    orient=np.ones(len(f),np.int8)
    for b,j,k in zip(child,parent[child],relation):orient[b]=orient[j]*k
    mask=orient<0;f[mask]=f[mask][:,[0,2,1]]
 m=trimesh.Trimesh(m.vertices,f,process=False)
if m.volume<0:m.invert()
print(len(m.faces),m.body_count,m.volume,m.is_watertight,m.is_winding_consistent,flush=True)
assert m.is_volume and m.is_watertight and m.is_winding_consistent and m.body_count==1
m.export(p/'remeshed.stl')
