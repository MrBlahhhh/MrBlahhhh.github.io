"""Small-strain orthotropic linear tetrahedra, mm, N, MPa. Run on Jaw.step meshes."""
import json,sys, time
import numpy as np
from scipy.sparse import coo_matrix
from cvxopt import cholmod, spmatrix, matrix
from scipy.spatial import cKDTree
h=float(sys.argv[1]); core_ratio=float(sys.argv[2])
mesh=np.load(f'mesh-{h:g}.npz')
x,t=mesh['x'],mesh['tet']; cells=x[t]; cent=cells.mean(axis=1)
D=cells[:,1:]-cells[:,:1]
vol=np.abs(np.linalg.det(D))/6
g=np.zeros((len(t),4,3));g[:,1:]=np.linalg.inv(D).transpose(0,2,1);g[:,0]=-g[:,1:].sum(axis=1)
B=np.zeros((len(t),6,12))
for n in range(4):
 a=3*n
 for j in range(3):B[:,j,a+j]=g[:,n,j]
 for row,i,j in [(3,0,1),(4,1,2),(5,0,2)]:
  B[:,row,a+i]=g[:,n,j];B[:,row,a+j]=g[:,n,i]
# Voigt xx,yy,zz,xy,yz,xz engineering shear. Coupon E values, assumed Poisson and shear.
ex,ez=3860,2180
S=np.diag([1/ex,1/ex,1/ez,2*(1+.32)/ex,1/900,1/900])
for i,j,nu in [(0,1,.32),(0,2,.30),(1,2,.30)]:S[i,j]=S[j,i]=-nu/ex
C=np.linalg.inv(S);assert np.linalg.eigvalsh(C).min()>0
scale=np.ones(len(t))
if core_ratio != 1:
 # Approximate perimeters and skins. Sample the boundary triangles then measure
 # distance in a metric with a 2.25 mm in-plane and 1 mm Z shell.
 tri=x[mesh['skin']]
 samples=np.concatenate([tri.mean(axis=1),*(tri[:,i] for i in range(3)),*((tri[:,i]+tri[:,(i+1)%3])/2 for i in range(3))])
 dims=np.array([2.25,2.25,1.0]);dist=cKDTree(samples/dims).query(cent/dims)[0];scale[dist>1]=core_ratio
corefrac=vol[scale<1].sum()/vol.sum()
ed=(t[:,:,None]*3+np.arange(3)).reshape(-1,12)
k=(B.transpose(0,2,1)@(C@B))*(vol*scale)[:,None,None]
K=coo_matrix((k.ravel(),(np.repeat(ed,12,axis=1).ravel(),np.tile(ed,(1,12)).ravel())),shape=(x.size,x.size)).tocsc(); del k
def weights(name,mask=None):
 f=mesh[name];p=x[f];ar=np.linalg.norm(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]),axis=1)/2
 w=np.zeros(len(x))
 if mask is None:
  for j in range(3): np.add.at(w,f[:,j],ar/3)
 else:
  # Seven point triangular quadrature, exact for fifth order polynomials.
  from itertools import permutations
  q=[([1/3]*3,.225)]
  for a,b,ww in [(.0597158718,.4701420641,.1323941527),(.7974269854,.1012865073,.1259391805)]:
   q.extend((tr,ww) for tr in set(permutations((a,b,b))))
  for bary,ww in q:
   pos=np.einsum('j,ijk->ik',bary,p);wws=ar*ww*mask(pos)
   for j in range(3): np.add.at(w,f[:,j],wws*bary[j])
 return w
wr=weights('right');nr=np.nonzero(wr)[0];w=wr[nr]/wr.sum()
rc=np.array([np.ptp(x[:,0])/2-25.4*.315,0,16.5]);lc=rc.copy();lc[0]*=-1
# Distributed equivalent wrench about the right ball. With the area centroid as
# intermediary, sum of forces and moments equals the requested external wrench.
rg=np.average(x[nr],axis=0,weights=w);r=x[nr]-rg
J=np.eye(3)*np.sum(w*np.sum(r*r,axis=1))-np.einsum('i,ij,ik->jk',w,r,r)
def load(force,moment):
 f=np.array(force,float);m=np.array(moment,float);omega=np.linalg.solve(J,m-np.cross(rg-rc,f))
 s=np.zeros_like(x);s[nr]=w[:,None]*(f+np.cross(omega,r))
 assert np.allclose(s.sum(0),f) and np.allclose(np.cross(x-rc,s).sum(0),m)
 return s
def outnodes(face):return np.unique(mesh[face])
def dofs(nodes):return (nodes[:,None]*3+np.arange(3)).ravel()
def calculate(fixed,loads):
 free=np.ones(x.size,dtype=bool);free[dofs(fixed)]=False
 from scipy.sparse import tril
 lo=tril(K[free][:,free],format='coo')
 A=spmatrix(lo.data,lo.row.astype('intp'),lo.col.astype('intp'),size=lo.shape)
 factor=cholmod.symbolic(A);cholmod.numeric(A,factor)
 F=np.stack([v.ravel() for v in loads],axis=1)
 rhs=matrix(F[free]);cholmod.solve(factor,rhs);U=np.zeros_like(F);U[free]=np.asarray(rhs)
 for j in range(len(loads)):
  reac=(K@U[:,j]-F[:,j]).reshape(-1,3)
  assert np.max(abs(reac.ravel()[free]))<1e-6
  assert np.linalg.norm(reac.sum(0)+loads[j].sum(0))<1e-5
  assert np.linalg.norm(np.cross(x-lc,reac+loads[j]).sum(0))<1e-4
 return U.T
print(h,core_ratio,len(x),'assembling service solves',flush=True)
# Unit force and unit torque, all three axes for subsequent payload selection.
unit=np.eye(3);zeros=np.zeros(3)
loads=[load(v,zeros) for v in unit]+[load(zeros,v) for v in unit]
us=calculate(outnodes('left'),loads)
def hexmask(p):
 # Corners of the hex are on the X axis; the inradius of a 10 mm AF head is 5 mm.
 normals=np.array([[np.cos(a),np.sin(a)] for a in np.pi/6+np.arange(3)*np.pi/3])
 return np.max(abs(p[:,:2]@normals.T),axis=1)<=5
head=weights('head',hexmask);wash=weights('back',lambda p:np.linalg.norm(p[:,:2],axis=1)<=9)
def central(w):
 f=np.zeros_like(x);f[:,2]=100*w/w.sum();return f
print('clamp solves',flush=True)
uc=calculate(np.union1d(outnodes('left'),outnodes('right')),[central(head),central(wash)])
U=np.vstack([us,uc]); sig=[]
for u in U:
 eps=np.einsum('eij,ej->ei',B,u[ed]);sig.append((eps@C.T)*scale[:,None])

# Compliance and stress at prescribed service loads, plus the independent clamp and torsion cases.
from pathlib import Path
def metrics(name,coeff):
    stress=np.tensordot(coeff,sig,axes=1)
    u=np.tensordot(coeff,U,axes=1).reshape(-1,3)
    xx,yy,zz,xy,yz,xz=stress.T
    vm=np.sqrt(((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)/2+3*(xy**2+yz**2+xz**2))
    order=np.argsort(vm)
    i=order[np.searchsorted(np.cumsum(vol[order]),.99*sum(vol))]
    hot=np.argmax(vm)
    av=np.average(u[nr],axis=0,weights=w)
    angle=np.linalg.solve(J,(w[:,None]*np.cross(r,u[nr]-av)).sum(0))
    motion=av+np.cross(angle,rc-rg+np.array([50.,0,0]))
    if name in ('normal','side','bolt'):
        np.savez_compressed(f'view-{name}.npz',stress=vm)
    return dict(p99=float(vm[i]),peak=float(vm[hot]),hotspot=cent[hot].round(2).tolist(),
                motion=float(np.linalg.norm(motion)),angle_x_degrees=float(np.rad2deg(angle[0])),
                max_node_motion=float(np.linalg.norm(u,axis=1).max()))
half=29.41995/2
cases=dict(normal=[0,0,-half,0,50*half,0,0,0],side=[0,-half,0,0,0,-half*50,0,0],twist=[0,0,0,500,0,0,0,0],bolt=[0,0,0,0,0,0,1,0],washer=[0,0,0,0,0,0,0,1])
out={name:metrics(name,case) for name,case in cases.items()}
out.update(elements=len(t),nodes=len(x),meshvol=float(vol.sum()),head_area=float(head.sum()),washer_area=float(wash.sum()))
Path(f'results-{h:g}.json').write_text(json.dumps(out,indent=2))
