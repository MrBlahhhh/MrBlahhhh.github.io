# Reproducing the four web geometries

Run tier.py with Python, NumPy, SciPy and Shapely to solve the density optimization and reconstruct the spline extrusion and cup features in each named length folder. Or use the included design.json directly. From this archive root, for example:

    solidcraft-cli run 62/design.json --in stock/widened-62.sc --save jaw.sc --out Jaw.step --out Jaw.stl --quality fine

Use stock/standard.sc for the long models. Each optimize-replay.py independently reproduces the density solution and verifies its objective gradient. For the 150 mm STL, run retessellate.py then finish150.py on the folder containing Jaw.step. The second tool writes remeshed.stl. The curvature-aware surface mesh replaces an invalid direct STL tessellation. This does not change the native solid.

For elasticity, run mesh-medium.py 1.7 then solve-fields.py 1.7 0.25 in a folder containing Jaw.step, with Gmsh, NumPy, SciPy and CVXOPT/CHOLMOD. Slice the STL with PrusaSlicer and the included profile.ini to reproduce the material comparison. No physical strength rating has been established.
