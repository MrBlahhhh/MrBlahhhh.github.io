from pathlib import Path
import sys, math
import trimesh,numpy as np
root=Path(__file__).parent
def hit(tris,x,y):
    a=tris[:,0];u=tris[:,1]-a;v=tris[:,2]-a
    dx=x-a[:,0];dy=y-a[:,1];det=u[:,0]*v[:,1]-v[:,0]*u[:,1]
    ok=np.abs(det)>1e-10
    s=np.divide(dx*v[:,1]-dy*v[:,0],det,where=ok,out=np.zeros_like(dx))
    t=np.divide(u[:,0]*dy-u[:,1]*dx,det,where=ok,out=np.zeros_like(dx))
    ok&=(s>=-1e-8)&(t>=-1e-8)&(s+t<=1+1e-8)
    return np.unique(np.round((a[:,2]+s*u[:,2]+t*v[:,2])[ok],4))
def check_mesh(f,l):
    m=trimesh.load_mesh(f);tri=m.triangles
    assert m.is_watertight and m.is_winding_consistent and m.is_volume
    assert abs(m.extents[0]-l)<.01
    shells=m.split(only_watertight=False)
    assert sum(s.volume>0 for s in shells)==1
    def expected(x,y,z):
        actual=hit(tri,x,y);assert np.allclose(actual,z,atol=.055) and len(actual)==len(z),(x,y,actual,z)
    for sign in [-1,1]:
        c=sign*(l/2-25.4*.315)
        for dx,y in [(0,0),(0,6.2),(-sign*4.2,7.1),(-sign*6.5,.9)]:
            actual=hit(tri,c+dx,y);assert abs(actual[-1]-(16.5-math.sqrt(12.75**2-dx**2-y**2)))<.05
        expected(sign*(l/2-.6),.02,[])
    expected(.03,.04,[]); expected(1.,4.3,[4.3,15.5]);expected(.04,-9.49,[0,9.8]);expected(.04,9.49,[0,20.2])
    for a in np.linspace(0,2*np.pi,36,endpoint=False):
        for r in [6.3,8.95]:
            assert hit(tri,r*np.cos(a),r*np.sin(a))[0]==0
    print(f.name,'one connected material domain;',len(shells)-1,'internal cavity shell(s); both socket radii, stem slots, bolt, guides and full washer bearing ring verified')
if __name__=='__main__':
    for n in sys.argv[1:]:
        check_mesh(root/n/'Jaw.stl',int(n.split('-')[0]))
