from pathlib import Path
import json,sys
import numpy as np
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parent
def run(L):
    # Solve with shallower cross ties in the ground structure.
    source=ROOT/('wide-opt.py' if L==62 else 'long-opt.py')
    ns={'__name__':'topology_model'}
    exec(compile(source.read_text().replace('width=3.4;h=12.','width=2.6;h=(5.8 if kind in ("hoop","diagonal","cup-tie") else 13.6)'),str(source),'exec'),ns)
    f=ROOT/str(L);ns['solve'](L,f)
    data=json.loads((f/'network.json').read_text());c=L/2-8.001
    geo={'__name__':'reconstruct'}
    src=(ROOT/('wide-geometry.py' if L==62 else 'long-geometry.py')).read_text()
    src=src.replace("assert shape.geom_type=='Polygon',shape.geom_type","").replace("    interior=[]","    if shape.geom_type=='MultiPolygon':\n        return shape\n    interior=[]")
    exec(compile(src,'rib_geometry','exec'),geo)
    factor=.83 if L==62 else .85
    allweb=geo['footprint'](data,factor)
    data2=dict(data);data2['densities']=[0 if e[2] in ('hoop','diagonal','cup-tie') else r for e,r in zip(data['edges'],data['densities'])]
    tall=geo['footprint'](data2,factor*.95).intersection(allweb.buffer(-.32,quad_segs=6)).buffer(-.10,quad_segs=6)
    commands=[]
    def op(ident,**kw):commands.append(dict(command=ident,params=kw))
    op('parameters.change',name='ArmLength',expression=f'{L} mm')
    for obj,height,label,mode in [(allweb,6.0,'Connected face web','new'),(tall,15.8,'Deep radials and edge ties','join')]:
        op('sketch.create',plane='XY',offset=(-.4 if mode=='new' else 5.15),name=label+' section')
        polys=[obj] if obj.geom_type=='Polygon' else list(obj.geoms)
        for g in polys:
            if g.area<3.0:continue
            for loop in [g.exterior,*g.interiors]:
                if Polygon(loop).area<2:continue
                n=max(9,int(np.ceil(loop.length/1.35)));points=[]
                for i in range(n):
                    pt=loop.interpolate(i/n,normalized=True);x=pt.x;slope=np.clip(x/c,-1,1)*.5
                    points.append([f'{x:.5f} mm + {slope:.7f} * (ArmLength - {L} mm)',round(pt.y,5)])
                op('sketch.spline.control_point',points=points,periodic=True)
        op('sketch.finish')
        kw=dict(body_name='Web and bearings') if mode=='new' else dict(targets=['Web and bearings'])
        op('solid.extrude',distance=height,operation=mode,name=label,**kw)
    if L==62:
        op('solid.cylinder',base=[0,0,-.15],radius=9.65,height=5.45,operation='join',targets=['Web and bearings'],name='M6 bearing land')
    for sign,label in [(-1,'Left'),(1,'Right')]:
        x=f'{sign} * (ArmLength / 2 - BallDiameter * 0.315)'
        op('solid.cone',base=[x,0,-.15],radius=5.8,top_radius=12.85,height=7.55,operation='join',targets=['Web and bearings'],name=label+' socket backing')
        op('solid.cone',base=[x,0,7.4],radius=12.85,top_radius=15.4,height=8.25,operation='join',targets=['Web and bearings'],name=label+' socket rim')
    op('solid.combine',target='Jaw',tools=['Web and bearings'],operation='intersect',keep_tools=False)
    (f/'design.json').write_text(json.dumps(commands));(f/'reconstruction.json').write_text(json.dumps(dict(scale=factor,shallow_height_mm=5.6,external_ring_count=len(allweb.interiors),high_solids=len(polys))))
if __name__=='__main__':
    for l in [62,120,95,150]:run(l)
