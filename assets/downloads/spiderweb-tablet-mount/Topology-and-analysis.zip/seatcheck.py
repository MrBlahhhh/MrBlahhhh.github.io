from pathlib import Path
import sys,numpy as np,json
g,d=map(Path,sys.argv[1:]);sys.path.insert(0,str(g))
from interface import inspect
for l in [62,120,95,150]:
 p=d/'tier-final'/str(l)
 b,bb,_=inspect(g/f'{l}-base'/'Jaw.step');s,ss,face=inspect(p/'Jaw.step')
 print(l,np.abs(s-b).max(),bb,ss,face,flush=True)
 np.testing.assert_allclose(s,b,atol=1e-4,rtol=2e-6)
 assert abs(bb-ss)<1e-4
 (p/'seatcheck.json').write_text(json.dumps(dict(seats=s.tolist(),hex_floor=ss,bed_area=face)))
