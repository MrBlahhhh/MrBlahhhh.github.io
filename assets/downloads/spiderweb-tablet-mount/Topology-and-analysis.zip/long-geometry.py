"""Reconstruct the optimized chords as printable fair ribs and preserve the two seat shells."""
from pathlib import Path
import numpy as np,math,json,sys
from shapely.geometry import LineString,Point,Polygon
from shapely.ops import unary_union

def footprint(data,factor):
    L=data['length'];p=np.array(data['points']);polys=[]
    for (a,b,kind,bow,ctr),rho in zip(data['edges'],data['densities']):
        if rho<data['threshold']:continue
        A,B=p[a],p[b];polyline=[A,B]
        if kind in ('hoop','tie','cup-tie'):
            chord=B-A;mid=(A+B)*.5;v=np.array(ctr)-mid
            v-=chord*np.dot(v,chord)/np.dot(chord,chord);v/=max(np.linalg.norm(v),1e-9)
            t=np.linspace(0,1,13)[:,None];polyline=A+(B-A)*t+4*t*(1-t)*v*np.linalg.norm(chord)*bow
        width=(1.08+1.8*rho)*(1 if L>=90 else .91)*factor
        if kind=='rail':width*=1.16
        if kind=='pad':width=3.5
        polys.append(LineString(polyline).buffer(width/2,quad_segs=6))
    # Washer, screw and guide bearing areas use the original coordinates.
    for y,r in [(0,9.80),(-9.5,4.4),(9.5,4.4)]:
        polys.append(Point(0,y).buffer(r,quad_segs=24))
    shape=unary_union(polys)
    assert shape.geom_type=='Polygon',shape.geom_type
    # Fair the re-entrant nodes and suppress gaps too small for the process.
    shape=shape.buffer(.58,quad_segs=6).buffer(-.58,quad_segs=6)
    interior=[]
    for loop in shape.interiors:
        hole=Polygon(loop)
        if hole.area>3.5 and not hole.buffer(-.63).is_empty:interior.append(loop)
    return Polygon(shape.exterior,interior)
def create(path,factor=1):
    data=json.loads((path/'network.json').read_text());L=data['length'];c=L/2-8.001;g=footprint(data,factor)
    commands=[]
    def op(id,**kw):commands.append(dict(command=id,params=kw))
    op('parameters.change',name='ArmLength',expression=f'{L} mm')
    op('sketch.create',plane='XY',offset=-.4,name='Optimized radial web and protected pads')
    for ring in [g.exterior,*g.interiors]:
        n=max(9,int(math.ceil(ring.length/1.35)))
        # Periodic control splines round each junction without faceting its printed outline.
        positions=[]
        for t in np.arange(n)/n:
            pt=ring.interpolate(t,normalized=True);x,y=pt.x,pt.y
            slope=np.clip(x/c,-1,1)*.5
            positions.append([f'{x:.5f} mm + {slope:.7f} * (ArmLength - {L} mm)',round(y,5)])
        op('sketch.spline.control_point',points=positions,periodic=True)
    op('sketch.finish')
    op('solid.extrude',distance=21.3,operation='new',body_name='Web and bearings',name='Full-depth web')
    for sign,label in [(-1,'Left'),(1,'Right')]:
        x=f'{sign} * (ArmLength / 2 - BallDiameter * 0.315)'
        op('solid.cone',base=[x,0,-.15],radius=5.8,top_radius=12.85,height=7.55,operation='join',targets=['Web and bearings'],name=label+' socket backing')
        op('solid.cone',base=[x,0,7.4],radius=12.85,top_radius=15.4,height=8.25,operation='join',targets=['Web and bearings'],name=label+' socket rim')
    op('solid.combine',target='Jaw',tools=['Web and bearings'],operation='intersect',keep_tools=False)
    (path/'design.json').write_text(json.dumps(commands))
    (path/'reconstruction.json').write_text(json.dumps(dict(width_scale=factor,planar_apertures_before_bosses=len(g.interiors),web_plan_area=g.area)))
    return g
if __name__=='__main__':
    from PIL import Image,ImageDraw
    for l in [62,95,120,150]:
        f=Path(sys.argv[1])/str(l);g=create(f)
        print(l,len(g.interiors),round(g.area),flush=True)
        im=Image.new('RGB',(1000,400),'#ebede5');dr=ImageDraw.Draw(im)
        k=min(925/l,10.)
        def xy(geom):return [(500+x*k,200-y*k) for x,y in geom.coords]
        dr.polygon(xy(g.exterior),fill='#254651')
        for ring in g.interiors:dr.polygon(xy(ring),fill='#ebede5')
        im.save(f/'plan.png')
