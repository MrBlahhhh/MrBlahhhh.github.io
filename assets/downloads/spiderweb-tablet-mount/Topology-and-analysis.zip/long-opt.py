"""Member topology optimization of a radial ground structure using a 3-D beam model."""
from pathlib import Path
import json,sys,math
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from scipy.optimize import minimize
def ground(L):
    c=L/2-8.001
    pts=[];lookup={};edges={}
    def node(x,y):
        xy=(round(x,5),round(y,5))
        if xy not in lookup:lookup[xy]=len(pts);pts.append(xy)
        return lookup[xy]
    def edge(a,b,kind,bow=0,center=None):
        if a!=b:edges.setdefault(tuple(sorted((a,b))),(a,b,kind,bow,center))
    clamp=node(0,0);balls=[node(-c,0),node(c,0)]
    if L==62:
        # One central orb centered on the physical fastener. The cup centers sit on the ±X rays.
        N=12
        rings=[]
        for j,(rx,ry) in enumerate([(17.05,10.8),(c+5.65,16.0)]):
            ring=[]
            for i in range(N):
                a=math.tau*i/N
                ring.append(node(rx*math.cos(a),ry*math.sin(a)))
            rings.append(ring)
            for i in range(N):
                edge(ring[i],ring[(i+1)%N],'hoop' if not j else 'tie',.20,[0,0])
                edge(clamp if not j else rings[0][i],ring[i],'spoke' if i%2==0 else 'ray')
                if j and i in (1,5,7,11):
                    near=0 if i in [1,11] else 6
                    edge(rings[0][near],ring[i],'diagonal')
        for s in (-1,1):
            b=balls[int(s==1)];idx=0 if s==1 else 6
            edge(b,rings[0][idx],'pad');edge(b,rings[1][idx],'pad')
            for k in [-1,1]:
                edge(b,rings[1][(idx+k)%N],'cup-ray')
                edge(b,rings[0][(idx+k)%N],'cup-ray')
    else:
        N=8
        for s,b in zip([-1,1],balls):
            cx=s*c*.5;hub=node(cx,0)
            rings=[]
            for j,r in enumerate([.55,1.]):
                ring=[]
                for i in range(N):
                    a=math.tau*i/N
                    x=math.copysign(abs(math.cos(a))**.74,math.cos(a));y=math.copysign(abs(math.sin(a))**.74,math.sin(a))
                    ring.append(node(cx+s*r*(c*.50)*x,r*15.8*y))
                rings.append(ring)
                for i in range(N):
                    edge(ring[i],ring[(i+1)%N],'hoop' if j==0 else 'tie',.18,[cx,0])
                    edge(hub if j==0 else rings[0][i],ring[i],'spoke' if i%2==0 else 'ray')
                    if j and i in (1,3,5,7):
                        # Candidate diagonal reinforcements in the outer band compete for the available volume.
                        edge(rings[0][0 if i in [1,7] else 4],ring[i],'diagonal')
            for sy in (-1,1):
                sign=1 if sy==1 else -1
                cp=node(0,sy*10.3);bp=node(s*c,sy*10.7)
                edge(clamp,cp,'pad');edge(b,bp,'pad')
                edge(cp,rings[-1][(4-sign)%N],'rail')
                edge(bp,rings[-1][sign%N],'rail')
                tip=node(s*(L/2-.6),sy*9.5)
                edge(b,tip,'cup-ray');edge(bp,tip,'cup-tie',.17,[s*c,0])
    return np.array(pts),list(edges.values()),balls,clamp
def matrices(P,E):
    K=[];lens=[]
    for a,b,kind,bow,ctr in E:
        delta=P[b]-P[a];l=np.linalg.norm(delta);lens.append(l);nx,ny=delta/l
        R=np.array([[nx,ny,0],[-ny,nx,0],[0,0,1]])
        T=np.kron(np.eye(4),R);k=np.zeros((12,12));width=3.4;h=12.
        if kind=='pad':width=9.
        A=width*h;Em=3000.;G=1120.;J=h*width**3*(1/3-.21*width/h*(1-(width/h)**4/12))
        k[np.ix_([0,6],[0,6])]=Em*A/l*np.array([[1,-1],[-1,1]])
        k[np.ix_([3,9],[3,9])]=G*J/l*np.array([[1,-1],[-1,1]])
        for dof,I,sgn in [([1,5,7,11],h*width**3/12,1),([2,4,8,10],width*h**3/12,-1)]:
            e=6*l*sgn
            k[np.ix_(dof,dof)]=Em*I/l**3*np.array([[12,e,-12,e],[e,4*l*l,-e,2*l*l],[-12,-e,12,-e],[e,2*l*l,-e,4*l*l]])
        K.append(T.T@k@T)
    return np.array(K),np.array(lens)
def solve(L,dest):
    P,E,balls,hub=ground(L);K,le=matrices(P,E);n=len(P)*6
    groups={};grp=[]
    for a,b,kind,_,__ in E:
        key=min(tuple(sorted((tuple(P[a]*[sx,sy]),tuple(P[b]*[sx,sy])))) for sx in [-1,1] for sy in [-1,1])
        if key not in groups:groups[key]=len(groups)
        grp.append(groups[key])
    grp=np.array(grp);ng=len(groups)
    lo=np.full(ng,.002)
    for i,edge in enumerate(E):
        minimum={'pad':1.,'hoop':.48,'tie':.30,'spoke':.40,'cup-ray':.40,'cup-tie':.45,'rail':.42}.get(edge[2],.002)
        lo[grp[i]]=max(lo[grp[i]],minimum)
    vol=np.bincount(grp,weights=le);vol/=sum(vol);vf=.59
    rho=lo+(1-lo)*(vf-vol@lo)/(1-vol@lo)
    dofs=np.array([np.r_[np.arange(6)+6*a,np.arange(6)+6*b] for a,b,*_ in E])
    rows=np.repeat(dofs,12,axis=1).ravel();cols=np.tile(dofs,(1,12)).ravel()
    F=np.zeros((n,4));right=6*balls[1];F[right+2,0]=-14.709975;F[right+4,0]=735.49875
    F[right+1,1]=-14.709975;F[right+5,1]=-735.49875;F[right+3,2]=500.;F[6*hub+2,3]=100
    def free(nodes):
        return np.setdiff1d(np.arange(n),np.concatenate([np.arange(6)+6*i for i in nodes]))
    supports=[(free(balls[:1]),[0,1,2]),(free(balls),[3])]
    wt=np.array([.30,.25,.25,.20])
    def evaluate(dens,power):
        x=dens[grp];e=.00001+(1-.00001)*x**power
        M=coo_matrix(((K*e[:,None,None]).ravel(),(rows,cols)),shape=(n,n)).tocsc()
        U=np.zeros_like(F)
        for active,load in supports:
            ix=np.ix_(active,load);U[ix]=splu(M[active][:,active]).solve(F[ix])
        compliance=(F*U).sum(axis=0)
        qe=np.einsum('eic,eij,ejc->ec',U[dofs],K,U[dofs])
        return compliance,qe
    ref=evaluate(np.ones(ng),1)[0];hist=[]
    for power in [1.,1.65,2.3,3.]:
        def obj(x):
            compliance,qe=evaluate(x,power)
            grad=np.bincount(grp,weights=-(1-.00001)*power*x[grp]**(power-1)*(qe@(wt/ref)),minlength=ng)
            return compliance@(wt/ref),grad
        begin=obj(rho)[0]
        res=minimize(obj,rho,jac=True,method='SLSQP',bounds=list(zip(lo,np.ones(ng))),constraints=[dict(type='ineq',fun=lambda x:vf-vol@x,jac=lambda x:-vol)],options=dict(maxiter=100,ftol=2e-7))
        assert res.success and vol@res.x<=vf+2e-6,(L,res.message,vol@res.x)
        hist.append([power,float(begin),float(res.fun),int(res.nit)]);rho=res.x
    out=dict(length=L,points=P.tolist(),edges=E,densities=rho[grp].tolist(),group_count=ng,budget=vf,achieved=float(vol@rho),history=hist,
             threshold=.19,frame_reference_compliances=ref.tolist(),case_weights=wt.tolist())
    dest.mkdir(exist_ok=True,parents=True);(dest/'network.json').write_text(json.dumps(out,indent=1))
    print('L',L,'members',len(E),'retained',sum(rho[grp]>=.19),'history',hist,flush=True)
if __name__=='__main__':
    for l in [62,95,120,150]:solve(l,Path(sys.argv[1])/str(l))
