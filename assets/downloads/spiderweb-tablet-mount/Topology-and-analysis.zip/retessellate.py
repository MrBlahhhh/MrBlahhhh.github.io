from pathlib import Path
import sys,gmsh,numpy as np
p=Path(sys.argv[1]);gmsh.initialize();gmsh.option.setNumber('General.Terminal',0)
gmsh.model.occ.importShapes(str(p/'Jaw.step'));gmsh.model.occ.synchronize()
gmsh.option.setNumber('Mesh.MeshSizeMax',.62)
gmsh.option.setNumber('Mesh.MeshSizeMin',.10)
gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',72)
gmsh.option.setNumber('General.NumThreads',1)
gmsh.model.mesh.generate(2)
tags,x,_=gmsh.model.mesh.getNodes()
v=x.reshape(-1,3)
lut=np.full(int(max(tags))+1,-1,dtype=np.int64);lut[tags.astype(int)]=np.arange(len(tags))
ts=[]
for _,tag in gmsh.model.getBoundary(gmsh.model.getEntities(3),oriented=True):
 ids=gmsh.model.mesh.getElementsByType(2,abs(tag))[1].astype(int)
 f=lut[ids].reshape(-1,3);ts.append(f)
np.savez_compressed(p/'surface-alternate.npz',v=v,f=np.vstack(ts))
gmsh.finalize()
