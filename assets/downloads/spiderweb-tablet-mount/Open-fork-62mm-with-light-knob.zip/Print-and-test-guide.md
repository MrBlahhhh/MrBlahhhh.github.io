# Open fork for two 1-inch balls

The 62 mm jaw uses curved ribs that divide at the M6 boss and wrap around each ball. The original preview shows the 11.11 g shape study. That jaw moved 0.612 mm vertically under the modeled 3 g tablet load. Its open roots were too flexible.

This reinforced prototype slices at 14.73 g per jaw. Tip-to-tip length is 62 mm and maximum width is 37.3 mm. Both jaws plus the shared M6 knob form one arm. The first organic wrap was 19.44 g per jaw, the original solid-cup jaw 15.77 g, and the prior spiderweb design 14.85 g. These are estimates with the same PAHT-CF slicing profile.

| Simulated load | 1.5 mm mesh | Limit | 1.05 mm mesh | Limit |
|---|---:|---:|---:|---:|
| Vertical tablet displacement | 0.2068 mm | 0.2301 mm | 0.2109 mm | 0.2347 mm |
| Sideways tablet displacement | 0.0621 mm | 0.0708 mm | 0.0627 mm | 0.07082 mm |
| One socket rim, 20 N | 0.04185 mm | 0.04265 mm | 0.04313 mm | 0.04434 mm |

The 3 g case uses a modeled 1.0 kg tablet and case with the center of mass 50 mm beyond the outer ball. Two jaws share the 29.42 N total load. Each limit is 125% of the solid reference on the corresponding mesh. The print STL passed watertightness, single-volume, ball-clearance, screw seat, washer support, stem-opening and guide checks.

Print two identical jaws and one knob. Place the washer land on the bed with the ball seats facing up. The mass comparison uses dried PAHT-CF, a hardened 0.4 mm nozzle, 0.20 mm layers, five perimeters and 40% gyroid. Inspect the free spans and overhangs in your slicer. Compare support against the actual printed rib finish. The quoted mass excludes supports.

Use an M6 × 1 × 45 mm 90° countersunk socket screw (length includes head), one M6 plain nut, and one 6.4 × 18 × 1.6 mm washer. Turn the second jaw 180° about its long axis so each post enters its opposing socket. Use a tethered dummy load for the first bench test, and mark the balls to check slip. Grip, hot-cabin creep, and breaking load still require physical testing. The native SolidCraft file uses ArmLength for tip-to-tip length. Simulations apply to the supplied 62 mm part.
