# M6 open-fork thumb knob

Print one knob with the round washer pad flat on the bed and the hex pocket facing up. The PAHT-CF comparison uses a 0.4 mm nozzle, 0.20 mm layers, five walls, 40% gyroid and supports off. The archived knob sliced at 4.87 g and the open-fork knob at 2.80 g. Three curved pads split around windows and join the nut hub on both sides.

Use the arm's original M6 plain hex nut, 45 mm countersunk screw and 18 mm washer. Drop the nut into the top pocket, place the washer between the knob and the jaw, then thread the screw into the nut. The nominal pocket measures 10.4 mm across flats, the through bore is 6.8 mm and the nut seats 3 mm above the underside. At the widest pad the turning radius is 16.61 mm, 0.61 mm larger than the original. Check clearance through one full turn on the mounted arm.

## Bench comparison

The linear elastic simulation fixes the six pocket faces over the seated nut height and loads the outside pads tangentially to 1 N·m. Loading one pad concentrates the force and puts a net side load on the nut. The rotation below is an equivalent angle calculated from work at the loaded surface. Each number is from the 0.8 mm mesh unless marked. The relative comparison assumes the same PAHT-CF properties and print orientation for all knobs.

| Knob | Sliced mass | Distributed grip | One finger |
|---|---:|---:|---:|
| Original | 4.87 g | 0.021° | 0.059° |
| Selected three-finger design | 2.80 g | 0.075° | 0.216° |
| Wider-window trial (1.1 mm mesh) | 2.56 g | 0.119° | 0.351° |

The selected knob also gave 0.203° under one finger on the 1.1 mm mesh. The video compares both open designs at that mesh size, with displacement enlarged 28 times. The applied torque is a comparison load. Nut slippage, layer failure and ultimate torque require a printed test. Start with the unloaded arm, hand-tighten and loosen it several times, then inspect the pocket corners and finger roots before testing with the tablet.
