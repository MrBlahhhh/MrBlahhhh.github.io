"""Render a fixed camera from the actual tetrahedron displacement and erosion history."""
from pathlib import Path
import sys,json,csv,functools,subprocess,math
import numpy as np
from PIL import Image,ImageDraw
from matplotlib.colors import LinearSegmentedColormap
sys.path.insert(0,str(Path(sys.argv[3])))
from art import paint,basis,text,unit
p,dst=map(Path,sys.argv[1:3]); summary=json.loads((p/'summary.json').read_text())
rows=list(csv.DictReader((p/'curve.csv').open()))
f=np.array([float(k['force']) for k in rows]);s=np.array([float(k['travel']) for k in rows]);damage=np.array([int(k['removed']) for k in rows])
g=np.load(p/'geometry.npz');x,t=g['x'],g['t'];isp=int(np.argmax(f));end=len(f)-1
m=len(t);face=np.vstack([t[:,i] for i in [[1,2,3],[0,3,2],[0,1,3],[0,2,1]]]);own=np.tile(np.arange(m),4)
tr=x[face];flip=np.einsum('ij,ij->i',np.cross(tr[:,1]-tr[:,0],tr[:,2]-tr[:,0]),x[t].mean(1)[own]-tr[:,0])>0
face[flip]=face[flip][:,[0,2,1]]
_,inv,n=np.unique(np.sort(face,axis=1),axis=0,return_inverse=True,return_counts=True)
assert n.max()==2
order=np.argsort(inv,kind='stable');inter=order[n[inv[order]]==2].reshape(-1,2)
neigh=np.full(len(face),m);neigh[inter[:,0]]=own[inter[:,1]];neigh[inter[:,1]]=own[inter[:,0]]
@functools.lru_cache(maxsize=6)
def load(i):
    with np.load(p/f'frame-{i:03d}.npz') as z:return z['u'],z['index'],z['alive']
def arrow(dr,xa,ya,xb,yb,col):
    dr.line((xa,ya,xb,yb),fill=col,width=3)
    dr.polygon([(xb,yb),(xb-7,yb-13),(xb+7,yb-13)],fill=col)
DARK='#11242a';LIGHT='#edf3e9';MUTED='#acc5c2';WARM='#ffc880';MINT='#89ddcb';GRID='#385055'
pal=LinearSegmentedColormap.from_list('strain',['#62a6ac','#70baae','#a7d9a2','#f2cb77','#f18b57','#ef5954'])
lut=np.round(pal(np.linspace(0,1,256))[:,:3]*255).astype(np.uint8)
W,H=1344,768;vw,vh=878,426
ax=basis([.22,-.97,.80]);initial=x@ax
light=unit(-.28*ax[:,0]-.58*ax[:,1]+.80*ax[:,2])
bg=np.array([17,36,42],np.uint8);hot=summary['first_cell']
amp=2.; off=np.array([vw*.48,vh*.42,0]);cen=(initial.max(0)+initial.min(0))*.5
scale=.90*min((vw-110)/np.ptp(initial[:,0]),(vh-95)/np.ptp(initial[:,1]))
def project(point):return (np.asarray(point)@ax-cen)*scale+off
def snapshots(a,b,count):
    if b<=a:return np.full(count,float(a))
    ix=np.arange(a,b+1);inc=.80*np.abs(np.diff(f[ix]))/max(f)+.85*np.diff(s[ix])/max(s)+.50*np.diff(damage[ix])/max(1,damage[-1])+.18/(b-a)
    q=np.r_[0,np.cumsum(np.maximum(inc,.000001))]
    return np.interp(np.linspace(0,q[-1],count),q,ix)
fps=24
time=np.concatenate([np.zeros(12),np.linspace(0,1,52),np.ones(24),snapshots(1,isp,66),np.full(25,isp),snapshots(isp,end,150),np.full(105,end)])
fmax=math.ceil(max(f)/25)*25;smax=max(1,math.ceil(max(s)))
def component_groups():
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    alive=load(end)[2];adj=own[inter];adj=adj[alive[adj].all(1)]
    mat=coo_matrix((np.ones(len(adj),bool),adj.T),shape=(m,m)).tocsr()
    _,labels=connected_components(mat,directed=False)
    surf=np.flatnonzero((neigh==m)&alive[own])
    lefts=labels[own[surf[np.isin(face[surf],g['left']).all(1)]]]
    rights=labels[own[surf[np.isin(face[surf],g['right']).all(1)]]]
    assert not np.intersect1d(lefts,rights).size
    return np.where(np.isin(labels,rights),1,np.where(np.isin(labels,lefts),0,2))
groups=component_groups() if 'disconnected' in summary['end'] else None
def frame(v,reveal=0.):
    a=int(v);b=min(a+1,end);mix=v-a
    u0,q0,alive=load(a);u1,q1,alive1=load(b);u=(1-mix)*u0+mix*u1;ratio=(1-mix)*q0+mix*q1
    extended=np.r_[alive,False];show=alive[own]&~extended[neigh];ids=own[show];bound=neigh[show]!=m
    deformed=x+amp*u;tri=deformed[face[show]]
    if reveal>0 and groups is not None:
        tri[groups[ids]==1]+=np.array([4.,0.,0.])*reveal
    normals=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);normals/=np.maximum(np.linalg.norm(normals,axis=1),1e-10)[:,None]
    shade=.66+.34*np.maximum(normals@light,0)
    color=lut[np.clip(ratio[ids]*255,0,255).astype(np.uint8)].copy()
    color[bound]=[255,170,137]
    if reveal>0 and groups is not None:
        marking=np.array([[104,183,184],[246,193,128],[221,150,135]])[groups[ids]]
        color=(color*(1-reveal)+marking*reveal).astype(np.uint8)
    clr=np.ascontiguousarray(color*shade[:,None],dtype=np.uint8)
    points=np.ascontiguousarray(project(tri),dtype=np.float32);pixels=np.empty((vh,vw,3),dtype=np.uint8);pixels[:]=bg
    paint(vw,vh,len(tri),points.ctypes.data,clr.ctypes.data,pixels.ctypes.data)
    out=Image.new('RGB',(W,H),DARK);dr=ImageDraw.Draw(out)
    text(dr,(40,22),'Bending the spiderweb jaw to failure',45,LIGHT,True)
    text(dr,(42,88),'62 mm double-socket arm   /   PAHT-CF   /   one jaw in a fixed-cup fixture',23,MUTED)
    dr.line((42,138,1302,138),fill=GRID,width=1)
    ox,oy=15,183
    out.paste(Image.fromarray(pixels),(ox,oy));dr=ImageDraw.Draw(out)
    force=(1-mix)*f[a]+mix*f[b];travel=(1-mix)*s[a]+mix*s[b]
    stage=('Elastic bending' if v<.98 else 'First tensile failure' if v<1.7 else 'Peak reaction' if abs(v-isp)<.8 else 'Separated pieces' if reveal>.01 else 'Cups disconnected' if v>end-.2 else 'Web cracking' if v<isp else 'Crack growth')
    text(dr,(43,154),stage,26,WARM if v>=.98 else MINT,True)
    tip=project(deformed[g['right']].mean(axis=0));left=project(x[g['left']].mean(axis=0))
    xp=int(tip[0]+ox+9);yp=int(tip[1]+oy-21)
    if reveal<=.01:arrow(dr,xp,yp-52,xp,yp,WARM)
    if v>=.98 and v<=2:
        hx,hy=project(deformed[t[hot]].mean(axis=0))[:2]+[ox,oy]
        dr.ellipse((hx-9,hy-9,hx+9,hy+9),outline='#fff6d8',width=3)
        dr.line((hx+7,hy-7,hx+45,hy-43),fill='#fff6d8',width=2)
    text(dr,(43,600),'Base-side fragment' if reveal>.01 else 'Base cup fixed',20,MUTED)
    text(dr,(856,600),'Cup-side fragment shown in gold' if reveal>.01 else 'Load applied 50 mm beyond the outer ball',20,MUTED,anchor='ra')
    dr.line((895,155,895,646),fill=GRID,width=1)
    tx=925;text(dr,(tx,160),'Reaction on one jaw',24,MUTED)
    text(dr,(tx,199),f'{force:.0f} N',55,LIGHT,True)
    text(dr,(tx,277),f'{travel:.2f} mm load-point travel',21,MINT)
    leftx,top,right,bot=969,372,1286,534
    text(dr,(tx,324),'Force (N)',17,MUTED)
    for iv in [0,.5,1]:
        yy=bot-iv*(bot-top);dr.line((leftx,yy,right,yy),fill=GRID,width=1)
        text(dr,(leftx-9,yy),f'{iv*fmax:g}',15,MUTED,anchor='rm')
    for iv in [0,.5,1]:
        xx=leftx+iv*(right-leftx);text(dr,(xx,bot+6),f'{iv*smax:g}',16,MUTED,anchor='ma')
    transform=lambda x,y:(leftx+x/smax*(right-leftx),bot-y/fmax*(bot-top))
    curve=[transform(s[j],f[j]) for j in range(a+1)]+[transform(travel,force)]
    if len(curve)>=2:dr.line(curve,fill=MINT,width=3)
    xx,yy=curve[-1];dr.ellipse((xx-5,yy-5,xx+5,yy+5),fill=WARM)
    text(dr,((leftx+right)/2,bot+34),'Load-point travel (mm)',16,MUTED,anchor='ma')
    text(dr,(tx,609),'4 mm exploded view' if reveal>.01 else 'Displacement shown at 2×',20,LIGHT,True)
    dr.line((42,650,1302,650),fill=GRID,width=1)
    text(dr,(44,671),'Tensile stress / assumed strength',18,MUTED)
    for j in range(211):
        col=tuple(int(c) for c in lut[j*255//210]);dr.line((45+j,710,45+j,720),fill=col)
    text(dr,(44,730),'0%',14,MUTED);text(dr,(257,730),'100%',14,MUTED,anchor='ra')
    dr.rectangle((324,710,339,723),fill='#ffa989');text(dr,(350,706),'New fracture face',18,LIGHT)
    text(dr,(1301,684),'First damage in this mesh   136 N' if reveal>.01 else 'Quasi-static brittle damage simulation',20,LIGHT,True,anchor='ra')
    text(dr,(1301,718),'Finer mesh   77 N   ·   Physical breaking force is unmeasured.' if reveal>.01 else 'Printed strength and rubber grip require a bench test.',17,MUTED,anchor='ra')
    return out
if len(sys.argv)>4:
 im=frame(float(sys.argv[4]));im.save(dst/'video-proof.png');sys.exit()
proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(fps),'-i','-','-an','-c:v','libx264','-threads','3','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(dst/'Spiderweb-62mm-bend-test.mp4')],stdin=subprocess.PIPE)
for j,v in enumerate(time):
    amount=np.clip((j-(len(time)-90))/26,0,1)
    im=frame(float(v),float(amount*amount*(3-2*amount)));proc.stdin.write(im.tobytes())
    if j==147:im.save(dst/'Bend-test-poster.jpg',quality=92)
proc.stdin.close();assert proc.wait()==0
