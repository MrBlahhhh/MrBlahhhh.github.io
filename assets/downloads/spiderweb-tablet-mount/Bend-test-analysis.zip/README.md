# Bend-to-failure simulation of one 62 mm spiderweb jaw

The filmed mesh first reached the assumed tensile limit at 136 N on one jaw, with 2.56 mm of load-point travel. The first damage was in a web rib beside the loaded cup. Several other ribs continued to carry load. The reaction peaked at 163 N and then fell as damage spread. The model lost its last continuous cross-section between the cup seats. The fixed cup tore away, leaving most of the web on the loaded side. The film offsets the fragments to show the break.

At the peak, the imposed remote travel was 3.130 mm. At the stopping condition the imposed travel was 16.544 mm and the reaction was 0.00 N. The finer 1.7 mm mesh first reached its tensile criterion at 76.93 N. The video uses the 2.4 mm mesh with 44,008 tetrahedra. The crack initiation force depends strongly on mesh size. These are comparative virtual fixture results for a single jaw. Rubber contact and clamping of the assembled mount are outside this fixture.

## Model and assumptions

The left sphere surface is fixed. A distributed wrench on the right sphere is equivalent to a downward unit force at a 50 mm offset. Displacement control uses the work-conjugate remote degree of freedom. A solve after each erosion event updates stiffness, displacement, stress and reaction. The resulting graph retains load drops at a fixed actuator position.

The linear orthotropic skin uses 3860 MPa in-plane and 2180 MPa normal-to-layer elastic moduli. The homogenized core uses 25% of both the shell stiffness and assumed tensile strength. The failure index is the largest of zero, the in-plane major tensile principal stress divided by in-plane tensile strength, and layer-normal opening stress divided by layer-normal tensile strength. Nominal solid-layer limits are 92 MPa in plane and 47 MPa through the layers. Once no intact elements connect the cups through shared faces, tensile reaction is set to zero. Fragments can still touch at an edge or point. The final gold fragment is shifted by 4 mm for visibility. The model does not predict its flight. Compressive and shear rupture are omitted. A failed element retains one millionth of its elastic stiffness for numerical conditioning and is hidden from the video surface.

The damage law omits calibrated fracture energy, post-yield plasticity, contact and geometry updates. Fracture paths, local failure forces and post-peak travel are mesh and law dependent. A fixed-cup tensile bending test could identify initiation, peak force, unloading slope and topology of the actual rupture. Measured print coupons and that force–travel curve would be needed to calibrate the model.

## Reproduce

Extract this archive. Install Python with NumPy, SciPy and CVXOPT including CHOLMOD. From the archive root run

    python bend.py mesh solve-fields.py run 2.4
    python bend-resume.py mesh solve-fields.py run 2.4
    python bend-sever.py mesh solve-fields.py run 2.4
    python bend-step.py mesh solve-fields.py refined 1.7 onset

The three successive stages continue the same displacement-controlled history. The first resolves individual tensile events, the second continues with 0.20 mm minimum travel increments to 3.5% of peak reaction, and the last continues until no face-connected path remains. The final command checks initiation on a finer mesh. The coarse run writes its complete history under run, including curve.csv and summary.json. Inputs and compact numerical results for both mesh sizes are included. To re-render after solving, install Pillow, Matplotlib, FFmpeg, a C compiler and the Lato fonts. Build the CPU rasterizer with

    cc -O3 -shared -fPIC renderer/raster.c -o renderer/raster.so -lm
    python movie.py run . renderer

The MP4 comprises elapsed playback time in arbitrary slowed stages. Its geometry uses 2× the computed displacement for visibility. Force and travel readings use true calculated values.

Material source: https://store.bblcdn.eu/s8/default/91dea87af3414d878a0696d2c51b98f7/Bambu_PAHT-CF_Technical_Data_Sheet_V2.pdf
