from pathlib import Path
import numpy as np,json,sys
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
p=Path(sys.argv[1]);g=np.load(p/'geometry.npz');x,t=g['x'],g['t'];m=len(t)
faces=np.vstack([t[:,f] for f in [[1,2,3],[0,3,2],[0,1,3],[0,2,1]]]);own=np.tile(np.arange(m),4)
_,inv,n=np.unique(np.sort(faces,axis=1),axis=0,return_inverse=True,return_counts=True)
order=np.argsort(inv,kind='stable');a=order[n[inv[order]]==2].reshape(-1,2);b=own[a]
outer=order[n[inv[order]]==1];left=own[outer[np.isin(faces[outer],g['left']).all(axis=1)]];right=own[outer[np.isin(faces[outer],g['right']).all(axis=1)]]
snap=sorted(p.glob('frame-*.npz'))[-1];z=np.load(snap);alive=z['alive'];ij=b[alive[b].all(1)]
K=coo_matrix((np.ones(len(ij),bool),ij.T),shape=(m,m)).tocsr();_,lab=connected_components(K,directed=False)
leftc=np.unique(lab[left[alive[left]]]);rightc=np.unique(lab[right[alive[right]]])
res=dict(state=snap.name,connected_through_faces=bool(np.intersect1d(leftc,rightc).size),remaining_solid_components=int(np.unique(lab[alive]).size),lost_elements=int((~alive).sum()))
tv=np.abs(np.linalg.det(x[t][:,1:]-x[t][:,:1]))/6
res['fixed_cup_fragment_mm3']=float(tv[alive & np.isin(lab,leftc)].sum())
res['loaded_cup_fragment_mm3']=float(tv[alive & np.isin(lab,rightc)].sum())
res['remaining_intact_mm3']=float(tv[alive].sum())
print(res);(p/'connectivity.json').write_text(json.dumps(res))
