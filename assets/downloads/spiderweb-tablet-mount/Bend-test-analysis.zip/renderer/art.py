"""Render orthographic exterior FEA facets with a CPU depth buffer; no GPU required."""
from pathlib import Path
import ctypes as ct, json, functools, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from matplotlib.colors import LinearSegmentedColormap
D=Path(__file__).resolve().parent
BG='#10232d'; PAPER='#f1f4f1'; INK='#162c36'; QUIET='#495e66'
cmap=LinearSegmentedColormap.from_list('stress',['#355384','#2f76a7','#259caa','#68c5ab','#c5de85','#ffda69','#ffa057','#ed604d','#b43148'])
lib=ct.CDLL(str(D/'raster.so')); paint=lib.paint
paint.argtypes=[ct.c_int]*3+[ct.c_void_p]*3; paint.restype=None
def font(n,bold=False):
    return ImageFont.truetype('/usr/share/fonts/truetype/lato/'+('Lato-Heavy.ttf' if bold else 'Lato-Regular.ttf'),n)
def text(draw,xy,t,sz=20,col=INK,b=False,**kw):
    draw.text(xy,t,font=font(sz,b),fill=col,**kw)
def unit(v):
    v=np.array(v,dtype=float)
    return v/np.linalg.norm(v)
def rgb(s):
    return tuple(bytes.fromhex(s.lstrip('#')))
def basis(view,under=False):
    v=unit(view);up=np.array([0.,0.,-1. if under else 1.])
    right=unit(np.cross(up,v));top=unit(np.cross(v,right))
    return np.vstack([right,-top,v]).T
