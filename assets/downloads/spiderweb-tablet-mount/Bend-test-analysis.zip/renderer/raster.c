#include <math.h>
#include <stdint.h>
#include <stdlib.h>

/* Orthographic, depth-tested, flat-shaded tetrahedron surface facets. */
void paint(int width,int height,int count,const float *v,const uint8_t *rgb,uint8_t *out) {
    float *depth=malloc(sizeof(float)*(size_t)width*height);
    for(int i=0;i<width*height;i++) depth[i]=-1e20f;
    for(int i=0;i<count;i++,v+=9,rgb+=3) {
        float ax=v[0],ay=v[1],bx=v[3],by=v[4],cx=v[6],cy=v[7];
        float det=(bx-ax)*(cy-ay)-(by-ay)*(cx-ax);
        if(fabsf(det)<1e-8f) continue;
        int left=fmaxf(0,floorf(fminf(ax,fminf(bx,cx))));
        int right=fminf(width-1,ceilf(fmaxf(ax,fmaxf(bx,cx))));
        int top=fmaxf(0,floorf(fminf(ay,fminf(by,cy))));
        int bottom=fminf(height-1,ceilf(fmaxf(ay,fmaxf(by,cy))));
        for(int y=top;y<=bottom;y++) for(int x=left;x<=right;x++) {
            float dx=x+.5f-ax,dy=y+.5f-ay;
            float s=(dx*(cy-ay)-dy*(cx-ax))/det,t=((bx-ax)*dy-(by-ay)*dx)/det;
            if(s<-.00003f || t<-.00003f || s+t>1.00003f) continue;
            float z=v[2]+s*(v[5]-v[2])+t*(v[8]-v[2]);
            int idx=y*width+x;
            if(z>depth[idx]) {
                depth[idx]=z;
                for(int k=0;k<3;k++) out[3*idx+k]=rgb[k];
            }
        }
    }
    free(depth);
}
