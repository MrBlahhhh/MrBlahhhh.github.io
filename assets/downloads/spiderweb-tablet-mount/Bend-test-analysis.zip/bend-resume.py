"""Displacement-controlled cantilever with a fixed base cup and a remote load on the device cup.
Run with mesh-*.npz and solve-fields.py (same elastic constants and fixture as the design study).
Element erosion is an uncalibrated brittle damage law. Units are mm, N, MPa.
"""
from pathlib import Path
import sys, time,json,csv
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from cvxopt import cholmod,spmatrix,matrix
model,struct,output,h=Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]),float(sys.argv[4])
first_only=len(sys.argv)>5 and sys.argv[5]=='onset'
output.mkdir(parents=True,exist_ok=True)
# Reuse the validated linear model's kinematics, orthotropic elasticity, infill proxy and exact load distribution.
code=struct.read_text()
code=code[code.index('import json'):code.index('def calculate(')]
code=code.replace("h=float(sys.argv[1]); core_ratio=float(sys.argv[2])","core_ratio=.25")
code=code.replace("mesh=np.load(f'mesh-{h:g}.npz')","mesh=np.load(model/f'mesh-{h:g}.npz')")
code=code[:code.index('k=(B.transpose')] + code[code.index('def weights('):]
exec(compile(code,str(struct),'exec'))
F=load([0,0,-1],[0,50,0]).ravel()
fixed=dofs(outnodes('left'));free=np.setdiff1d(np.arange(x.size),fixed)
lookup=np.full(x.size,-1,int);lookup[free]=np.arange(len(free));dd=lookup[ed]
i,j=np.tril_indices(12);rr,cc=dd[:,i],dd[:,j];mask=(rr>=0)&(cc>=0)
idx=(np.maximum(rr,cc)[mask].astype(np.int64)*len(free)+np.minimum(rr,cc)[mask])
keys,mapping=np.unique(idx,return_inverse=True);rk=keys//len(free);ck=keys%len(free)
ke=(B.transpose(0,2,1)@(C@B))*(vol*scale)[:,None,None]
vals=ke[:,i,j][mask];del ke
el=np.broadcast_to(np.arange(len(t))[:,None],mask.shape)[mask]
def build(mult):
    a=np.bincount(mapping,vals*mult[el],minlength=len(keys))
    return spmatrix(a,rk.astype('intp'),ck.astype('intp'),size=(len(free),)*2)
ones=np.ones(len(t));factor=cholmod.symbolic(build(ones));loadvec=F[free]
def unit_solve(mult):
    A=build(mult)
    cholmod.numeric(A,factor)
    rhs=matrix(loadvec);cholmod.solve(factor,rhs)
    u=np.zeros(x.size);u[free]=np.asarray(rhs).ravel()
    return u,float(u@F)
def strength_index(u):
    eps=np.einsum('eij,ej->ei',B,u[ed]);stress=(eps@C.T)*scale[:,None]
    xx,yy,zz,xy,yz,xz=stress.T
    # Orthotropic maximum tensile stress in material directions.
    # Compare major principal tensile stress in the print plane and opening stress normal to layers.
    # Assumed tensile-strength fraction for the softer homogenized core follows its stiffness fraction.
    p=.5*(xx+yy)+np.hypot(.5*(xx-yy),xy)
    return np.maximum.reduce([p/(92*scale),zz/(47*scale),np.zeros(len(t))])
left=outnodes('left');right=outnodes('right')
def connected(alive):
    pair=np.concatenate([t[alive][:,[0,1]],t[alive][:,[0,2]],t[alive][:,[0,3]]])
    mat=coo_matrix((np.ones(len(pair),bool),(pair[:,0],pair[:,1])),shape=(len(x),len(x))).tocsr()
    _,labels=connected_components(mat,directed=False)
    return bool(np.intersect1d(labels[left],labels[right]).size)
mult=ones.copy();alive=np.ones(len(t),bool);u,flex=unit_solve(mult);score=strength_index(u)
first=1/np.max(score);start=first*flex;at=int(np.argmax(score))
meta=dict(size_mm=h,first_N_per_jaw=first,first_displacement_mm=start,first_location_mm=cent[at].tolist(),compliance_mm_per_N=flex,first_cell=at)
print(meta,flush=True)
(output/'onset.json').write_text(json.dumps(meta,indent=2))
if first_only:sys.exit()
np.savez_compressed(output/'geometry.npz',x=x,t=t,left=left,right=right)
records=[];peak=0;delta=start;stage=0
def write_state(delta,force,u,score):
    n=len(records);records.append(dict(step=n,travel=float(delta),force=float(force),removed=int((~alive).sum()),removed_volume=float(vol[~alive].sum())))
    np.savez_compressed(output/f'frame-{n:03d}.npz',u=(u*force).reshape(-1,3).astype(np.float32),index=(score*force).astype(np.float32),alive=alive)
    return records[-1]
with (output/'curve.csv').open() as stream:
    records=[dict(step=int(q['step']),travel=float(q['travel']),force=float(q['force']),removed=int(q['removed']),removed_volume=float(q['removed_volume'])) for q in csv.DictReader(stream)]
old=json.loads((output/'summary.json').read_text());last=records[-1]
assert old['end']=='event budget'
prev=np.load(output/f"frame-{last['step']:03d}.npz")
alive=prev['alive'];alive[alive&(prev['index']>=1-3e-7)]=False;mult[~alive]=1.e-6
delta=last['travel'];peak=old['peak_N_per_jaw']
for stage in range(old['event_count'],1500):
    if stage:u,flex=unit_solve(mult);score=strength_index(u);score[~alive]=0
    crit=1/max(score.max(),1e-12);force=delta/flex
    if force<crit*(1-3e-7):
        # Sample exact next onset in displacement control; store the relaxed state first.
        write_state(delta,force,u,score)
        if stage and force<peak*.035:
            meta['end']='reaction below 3.5% of peak';break
        delta=max(crit*flex,delta+.20);force=delta/flex
    peak=max(peak,force)
    state=write_state(delta,force,u,score)
    if stage%7==0:print(stage,state,flush=True)
    if stage>3 and force<peak*.035:
        meta['end']='reaction below 3.5% of peak';break
    failed=alive&(score*force>=1-3e-7)
    if not np.any(failed):raise RuntimeError('failed to locate next event')
    alive[failed]=False;mult[~alive]=1.e-6
    if not connected(alive):
        # After loss of connectivity, the eroded cells contribute no physical reaction.
        u2=u*force;state=write_state(delta,0,u,score)
        np.savez_compressed(output/f'frame-{len(records)-1:03d}.npz',u=u2.reshape(-1,3).astype(np.float32),index=np.zeros(len(t),np.float32),alive=alive)
        meta['end']='cups mechanically disconnected';break
else:meta['end']='event budget'
meta.update(peak_N_per_jaw=peak,final_state=records[-1],event_count=stage+1)
(output/'summary.json').write_text(json.dumps(meta,indent=2))
with (output/'curve.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
print(meta,flush=True)
